Package implémentent une solution de traitement de données et une implémentation de l'algorithme de dijkstra

Cas d'utilisation
importer des données avec Importation
les traiter avec Traitement
effectuer une recherche du plus court chemin avec Dijkstra
exporter les données traitées avec Exportation